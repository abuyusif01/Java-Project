
import java.util.concurrent.atomic.AtomicInteger;
import java.util.logging.Logger;
import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import java.io.*;
public class result extends Application{

	Button btnTrue = new Button("  To Menu  ");
	Button btnFalse = new Button("Exit");
	Label lb1 = new Label("YOUR QUIZ RESULT");
	Button view = new Button("View Score");


	public void start(Stage primaryStage) {

		Image image = new Image(new File(StartUp.app_icon).toURI().toString(),250,250, false, false);


		VBox vBox= new VBox();
		btnTrue.setStyle("-fx-background-color: #2A8CCD;-fx-text-fill: White;-fx-font-size: 1.2em;");
		btnFalse.setStyle("-fx-background-color: #2A8CCD;-fx-text-fill: White;-fx-font-size: 1.2em;");

		btnTrue.setPrefWidth(220); //button size
		btnFalse.setPrefWidth(220);

		lb1.setStyle("-fx-text-fill: black;-fx-font-size: 3.2em;font-weight: bold;");
		view.setStyle("-fx-text-fill: grey;-fx-font-size: 1.9em;font-weight: bold;");
		vBox.setAlignment(Pos.TOP_CENTER);
		vBox.getChildren().add(lb1);
		vBox.getChildren().add(new ImageView(image));
		vBox.getChildren().add(view);
		vBox.setStyle("-fx-background-color: #EBF7FF");
	    BorderPane borderPane = new BorderPane();
	    borderPane.setCenter(vBox);
	    BorderPane.setAlignment(vBox, Pos.CENTER);
	    AtomicInteger count = new AtomicInteger();
	    view.setOnAction(e ->{
				try {
					if (count.get() == 0)
					{
						count.getAndIncrement();
						String labelResultText = StartUp.UserGrade + " / " + StartUp.count;
						Label lb2 = new Label (labelResultText); // extract the result from calculateResult class
						vBox.getChildren().add(new Label(" "));
						lb2.setStyle("-fx-text-fill: black;-fx-font-size: 3.2em;font-weight: bold;");
						vBox.getChildren().add(lb2);

						vBox.getChildren().add(btnTrue);
						vBox.getChildren().add(new Label(" "));
						vBox.getChildren().add(btnFalse);
					}


			}
			catch(Exception ex){Logger.getLogger(StartUp.class.getName()).log(null);}
			});
			btnTrue.setOnAction(e ->{try{ StartUp toStartUp=new StartUp();toStartUp.start(primaryStage); //back to start page
			}
			catch(Exception ex){Logger.getLogger(StartUp.class.getName()).log(null);}
			});
	    btnFalse.setOnAction(e ->{
		    try{
		    		System.exit(0);

		    }
		    catch(Exception ex){Logger.getLogger(Introduction.class.getName()).log(null);}
	    });

		Scene scene = new Scene(borderPane,700,636);
		primaryStage.setTitle("RESULT");
		primaryStage.setScene(scene);
		primaryStage.setResizable(false);
		primaryStage.getIcons().add(new Image(new File(StartUp.app_icon).toURI().toString()));
		primaryStage.show();

	}

	public static void main(String[] args) {

	    launch(args);
	}
}