import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class GenerateCountryFlag {
    public List<String> OriginalArray = new ArrayList<>(); // country names
    public ArrayList<String> UserOutput = new ArrayList<>(); // random generated from country names
    public ArrayList<String> finalUserOutput = new ArrayList<>(); // the button text
    public String key;

    Random r = new Random();
    private void addElement(ArrayList<String> FinalUserOutput, String str) {
        if (!FinalUserOutput.contains(str)) {
            FinalUserOutput.add(str);
        }
    }

    public void init(int n) {
        for (int i = 0; i < n; i++) {
            String add_to_array_list = OriginalArray.get(r.nextInt(OriginalArray.size()));
            if (!UserOutput.contains(add_to_array_list)) {
                UserOutput.add(add_to_array_list);
            }
        }
        UserOutput.add(r.nextInt(n), key); /* force the key tobe in the arraylist   UserOutput.add(r.nextInt(n), key); */
    }

    public void finalise_everything(int n) {
        for (int i = 0; i < n; i++) {
            addElement(finalUserOutput, UserOutput.get(i));
        }
    }

    public void set_original_array_list(List<String> array) {
        OriginalArray = array;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String GetButtonName(int n) {
        return finalUserOutput.get(n);
    }
}