import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.logging.Logger;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;

public class Introduction extends Application {

	Button btnMainMenu = new Button("Main Menu ");
	Button btnExit = new Button("EXIT");

	String[] line = new String[50];
	int count = 0;
	
	public void start(Stage primaryStage)  {
		List<String> lines = new ArrayList<>();
        try (Scanner br = new Scanner(new File("resources/aboutUs.txt")))
        {
            while (br.hasNext()) {
            	line[count] = br.nextLine();
                lines.add(line[count]);
                count++;
            }
        } catch (IOException e) {
            e.printStackTrace();
        } 
        ListView<String> listView = new ListView<>();
        listView.setItems(FXCollections.observableList(lines));
        
		GridPane pane = new GridPane();
		btnMainMenu.setStyle("-fx-background-color: #2A8CCD;-fx-text-fill: White;-fx-font-size: 1.2em;");
		btnExit.setStyle("-fx-background-color: #2A8CCD;-fx-text-fill: White;-fx-font-size: 1.2em;");
		pane.setAlignment(Pos.CENTER);
		pane.setVgap(10);
		Image image = new Image(new File("resources/Images/MainLogo.png").toURI().toString(),690,150, false, false);
	    pane.getChildren();
	    pane.setStyle("-fx-background-color: #EBF7FF");
	    
	    HBox hBox = new HBox();
	    hBox.setSpacing(10);
	    hBox.setAlignment(Pos.CENTER);
	    hBox.setPrefSize(1000, 0);
	    btnExit.setPrefWidth(100);
	    btnMainMenu.setPrefWidth(100);

	    hBox.getChildren().addAll(btnMainMenu, btnExit);
	    
	   	
		pane.add(new ImageView(image),0,0);
		pane.add(listView, 0, 1);
		pane.add(hBox,0,6);
		pane.setVgap(12);
		pane.setAlignment(Pos.CENTER);
		
	    BorderPane borderPane = new BorderPane();
	    borderPane.setTop(pane);
	    BorderPane.setAlignment(pane, Pos.CENTER);

	    btnMainMenu.setOnAction(e ->{try{ StartUp toStartUp=new StartUp();toStartUp.start(primaryStage); //back to start page
	    }
	    catch(Exception ex){Logger.getLogger(StartUp.class.getName()).log(null);}
	    });
	    
	    btnExit.setOnAction(e ->{
		    try{ 
		    		System.exit(0);
		    }
		    catch(Exception ex){Logger.getLogger(Introduction.class.getName()).log(null);}
		    });
	    
	  
		Scene scene = new Scene(borderPane,700,659);
		primaryStage.setTitle("About Us");
		primaryStage.setScene(scene);
		primaryStage.show();
		primaryStage.getIcons().add(new Image(new File(StartUp.app_icon).toURI().toString()));
		primaryStage.setResizable (false);
		
	}
	
	public static void main(String[] args) {
		launch(args);
		}
	}