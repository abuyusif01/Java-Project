import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;
import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;

public class quiz extends Application {
	int btnSize = 160;
	int doubleBtnSize = 245;
	int btnOptionCount = 0;
	static int quiz_count = 5; /*allowing the user to enter how many question needed*/
	List<String> countryTokens = new ArrayList<>();

	public void start(Stage primaryStage) throws FileNotFoundException {

		Random r = new Random();
		Alert a = new Alert(Alert.AlertType.NONE);

		String countryNamePath= "resources/Flags/FlagNames";
		Scanner scanCountryName = new Scanner(new File(countryNamePath));
		while(scanCountryName.hasNext())
		{
			countryTokens.add(scanCountryName.nextLine());
		}
		String[] countryTokensToArray = countryTokens.toArray(new String[0]); // making arraylist to array
		String countryFlagNameUncut = countryTokensToArray[r.nextInt(countryTokensToArray.length)];
		String countryFlagName = "resources/Flags/"+countryFlagNameUncut+".jpg";
		Image image = new Image(new File(countryFlagName).toURI().toString(),500,650, true, true);


		GenerateCountryFlag genAnswer = new GenerateCountryFlag();

		genAnswer.setKey(countryFlagNameUncut); // the answer
		genAnswer.set_original_array_list(countryTokens);
		genAnswer.init(3); // number of buttons
		genAnswer.finalise_everything(3);

		Label labelChooseCountryByName = new Label("\tCHOOSE THE COUNTRY NAME");
		Button btnOption1 = new Button(genAnswer.GetButtonName(0));
		Button btnOption2 = new Button(genAnswer.GetButtonName(1));
		Button btnOption3 = new Button(genAnswer.GetButtonName(2));
		Button btnNext = new Button("Next");
		Button btnMainMenu = new Button("Main Menu");



		btnOption1.setPrefWidth(btnSize);
		btnOption2.setPrefWidth(btnSize);
		btnOption3.setPrefWidth(btnSize);
		btnMainMenu.setPrefWidth(doubleBtnSize);
		btnNext.setPrefWidth(doubleBtnSize);
		

		btnOption1.setStyle("-fx-text-fill: White;-fx-background-color: #2A8CCD;-fx-font-size: 1.2em; ");
		btnOption2.setStyle("-fx-text-fill: White;-fx-background-color: #2A8CCD;-fx-font-size: 1.2em; ");
		btnOption3.setStyle("-fx-text-fill: White;-fx-background-color: #2A8CCD;-fx-font-size: 1.2em; ");
		btnNext.setStyle("-fx-text-fill: White;-fx-background-color: #2A8CCD;-fx-font-size: 1.2em; ");
		btnMainMenu.setStyle("-fx-text-fill: White;-fx-background-color: #2A8CCD;-fx-font-size: 1.2em; ");
		labelChooseCountryByName.setStyle("-fx-text-fill: grey;-fx-font-size: 2.2em; ");


		// OnActions
		btnNext.setOnAction(e -> {
			try
			{
				this.start(primaryStage);
				btnOptionCount = 0;//back to start page
			}
			catch(Exception ex)
			{
				System.out.println("Something went wrong");
			}
		});

		btnMainMenu.setOnAction(e -> {
			try
			{
				new StartUp().start(primaryStage); //back to start page
				StartUp.count = 0;
				StartUp.UserGrade = 0;
			}
			catch(Exception ex)
			{
				System.out.println("Something went wrong");
			}
		});

		btnOption1.setOnAction(e -> {
			try {

				if (btnOptionCount == 0) {
					a.setTitle(countryFlagNameUncut + " Flag");
					a.setHeaderText(" ");
					if (btnOption1.getText().equals(countryFlagNameUncut)) {
						a.setContentText("Correct Answer");
						a.setAlertType(Alert.AlertType.INFORMATION);
						a.show();

						StartUp.UserGrade++;
						StartUp.count++;
						if (StartUp.count == quiz_count) {
							result res = new result();
							res.start(primaryStage);
						} else if (StartUp.count > quiz_count) {
							StartUp.count = 0;
							StartUp.UserGrade = 0;
						}

				} else {
					StartUp.count++;
					a.setContentText("Wrong Answer");
					a.setAlertType(Alert.AlertType.ERROR);
					a.show();

					if (StartUp.count == quiz_count) {
						result res = new result();
						res.start(primaryStage);
					} else if (StartUp.count > quiz_count) {

						StartUp.count = 0;
						StartUp.UserGrade = 0;
					}
				}
			}
				else
				{
					a.setContentText("Only Can be Selected Once");
					a.setAlertType(Alert.AlertType.ERROR);
					a.show();
				}
		}

		catch(Exception ex)
		{
			System.out.println("Something went wrong");
		}
			btnOptionCount ++;
		});


		btnOption2.setOnAction(e -> {
			try {

				if (btnOptionCount == 0) {
					a.setTitle(countryFlagNameUncut + " Flag");
					a.setHeaderText(" ");
					if (btnOption2.getText().equals(countryFlagNameUncut)) {
						a.setContentText("Correct Answer");
						a.setAlertType(Alert.AlertType.INFORMATION);
						a.show();

						StartUp.UserGrade++;
						StartUp.count++;
						if (StartUp.count == quiz_count) {
							result res = new result();
							res.start(primaryStage);
						} else if (StartUp.count > quiz_count) {
							StartUp.count = 0;
							StartUp.UserGrade = 0;
						}

					} else {
						StartUp.count++;
						a.setContentText("Wrong Answer");
						a.setAlertType(Alert.AlertType.ERROR);
						a.show();

						if (StartUp.count == quiz_count) {
							result res = new result();
							res.start(primaryStage);
						} else if (StartUp.count > quiz_count) {

							StartUp.count = 0;
							StartUp.UserGrade = 0;
						}
					}
				}
				else
				{
					a.setContentText("Only Can be Selected Once");
					a.setAlertType(Alert.AlertType.ERROR);
					a.show();
				}
			}

			catch(Exception ex)
			{
				System.out.println("Something went wrong");
			}
			btnOptionCount ++;
		});


		btnOption3.setOnAction(e -> {
			try {

				if (btnOptionCount == 0) {
					a.setTitle(countryFlagNameUncut + " Flag");
					a.setHeaderText(" ");
					if (btnOption3.getText().equals(countryFlagNameUncut)) {
						a.setContentText("Correct Answer");
						a.setAlertType(Alert.AlertType.INFORMATION);
						a.show();

						StartUp.UserGrade++;
						StartUp.count++;
						if (StartUp.count == quiz_count) {
							result res = new result();
							res.start(primaryStage);
						} else if (StartUp.count > quiz_count) {
							StartUp.count = 0;
							StartUp.UserGrade = 0;
						}

					} else {
						StartUp.count++;
						a.setContentText("Wrong Answer");
						a.setAlertType(Alert.AlertType.ERROR);
						a.show();

						if (StartUp.count == quiz_count) {
							result res = new result();
							res.start(primaryStage);
						} else if (StartUp.count > quiz_count) {

							StartUp.count = 0;
							StartUp.UserGrade = 0;
						}
					}
				}
				else
				{
					a.setContentText("Only Can be Selected Once");
					a.setAlertType(Alert.AlertType.ERROR);
					a.show();
				}
			}

			catch(Exception ex)
			{
				System.out.println("Something went wrong");
			}
			btnOptionCount ++;
		});

		HBox mainMenu = new HBox(btnMainMenu,btnNext);
		mainMenu.setSpacing(10);

		GridPane pane1 = new GridPane();
		HBox hbox = new HBox(btnOption1,btnOption2,btnOption3);

		hbox.setSpacing(10);
		pane1.setVgap(10);
		pane1.setAlignment(Pos.TOP_CENTER);
		pane1.add(labelChooseCountryByName, 1, 1);
		pane1.add(new ImageView(image),1,2);
		pane1.add(hbox,1,3);
		pane1.add(mainMenu, 1, 4);
		pane1.setStyle("-fx-background-color: #EBF7FF");

		BorderPane borderPane = new BorderPane();
		borderPane.setCenter(pane1);

		Scene scene = new Scene(borderPane,700,650);
		primaryStage.setTitle("GEOGRAPHY SKILLS QUIZ");
		primaryStage.setScene(scene);
		primaryStage.setResizable(false);
		primaryStage.getIcons().add(new Image(new File(StartUp.app_icon).toURI().toString()));
		primaryStage.show();
	    
	}
	
	public static void main(String[] args) {	
	    launch(args);
	  }

}