import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class gallery extends Application {

    int doubleBtnSize = 245;
    int btnOptionCount = 0;
    List<String> countryTokens = new ArrayList<>();

    public void start(Stage primaryStage) throws FileNotFoundException {

        Random r = new Random();
        String countryNamePath = "resources/Flags/FlagNames";
        Scanner scanCountryName = new Scanner(new File(countryNamePath));
        // storing the values in a list
        while (scanCountryName.hasNext()) {
            countryTokens.add(scanCountryName.nextLine());
        }

        // making arraylist to array
        String[] countryTokensToArray = countryTokens.toArray(new String[0]);

        // the country name (correct answer)
        String countryFlagNameUncut = countryTokensToArray[r.nextInt(countryTokensToArray.length)];

        // the image path
        String countryFlagName = "resources/Flags/" + countryFlagNameUncut + ".jpg";

        // image obj to project on the screen
        Image image = new Image(new File(countryFlagName).toURI().toString(), 500, 650, true, true);

        GenerateCountryFlag genAnswer = new GenerateCountryFlag();
        genAnswer.setKey(countryFlagNameUncut); // the answer
        genAnswer.set_original_array_list(countryTokens);
        genAnswer.init(3); // number of buttons
        genAnswer.finalise_everything(3);

        Label labelChooseCountryByName = new Label(countryFlagNameUncut);
        Button btnNext = new Button("Next");
        Button btnMainMenu = new Button("Main Menu");
        btnNext.setPrefWidth(doubleBtnSize);
        btnMainMenu.setPrefWidth(doubleBtnSize);
        btnNext.setStyle("-fx-text-fill: White;-fx-background-color: #2A8CCD;-fx-font-size: 1.2em; ");
        btnMainMenu.setStyle("-fx-text-fill: White;-fx-background-color: #2A8CCD;-fx-font-size: 1.2em; ");
        labelChooseCountryByName.setStyle("-fx-text-fill: grey;-fx-font-size: 2.2em; ");


        btnNext.setOnAction(e -> {
            try {
                this.start(primaryStage);
                btnOptionCount = 0;//back to start page
            } catch (Exception ex) {
                System.out.println("Something went wrong");
            }
        });
        btnMainMenu.setOnAction(e -> {
            try {
                new StartUp().start(primaryStage); //back to start page
                StartUp.count = 0;
                StartUp.UserGrade = 0;
            } catch (Exception ex) {
                System.out.println("Something went wrong");
            }
        });

        VBox mainMenu = new VBox();
        mainMenu.setSpacing(10);
        mainMenu.setAlignment(Pos.CENTER);
        mainMenu.getChildren().add(labelChooseCountryByName);
        mainMenu.getChildren().add(btnNext);
        mainMenu.getChildren().add(btnMainMenu);

        GridPane pane1 = new GridPane();

        pane1.setVgap(10);
        pane1.setAlignment(Pos.TOP_CENTER);
        pane1.add(new ImageView(image), 1, 1);
        pane1.add(mainMenu, 1, 4);
        pane1.setStyle("-fx-background-color: #EBF7FF");

        BorderPane borderPane = new BorderPane();
        borderPane.setCenter(pane1);

        Scene scene = new Scene(borderPane, 700, 650);
        primaryStage.setTitle("Photo Gallery");
        primaryStage.setScene(scene);
        primaryStage.setResizable(false);
        primaryStage.getIcons().add(new Image(new File(StartUp.app_icon).toURI().toString()));
        primaryStage.show();

    }

    public static void main(String[] args) {
        launch(args);
    }

}