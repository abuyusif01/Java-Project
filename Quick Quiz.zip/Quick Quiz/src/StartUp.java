
import java.util.logging.Logger;
import java.io.File;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

public class StartUp extends Application {
	static int UserGrade = 0; // how many question user answered correctly
	static int count = 0; // how many times user clicked at a button at a time

	static String app_icon = "resources/Images/app_icon.png";

	Label labelTryYourGeoSkills = new Label("\tTEST YOUR GEOGRAPHY SKILLS");
	Button btnAboutQuickQuiz = new Button("ABOUT US");
	Button btnTryItOut = new Button("TRY IT OUT!");
	Button btnGallery = new Button("COUNTRY FLAGS");
	Button btnExit = new Button("EXIT");
	int btnSize = 200;

	@Override
	public void start(Stage primaryStage) {

		Image world_image = new Image(new File("resources/Images/World.jpg").toURI().toString(),500,700, true, true);

		GridPane pane = new GridPane();
		pane.setHgap(10);
		pane.setVgap(10);
		pane.setPadding(new Insets(10));
		pane.add(btnAboutQuickQuiz, 0, 0);
		pane.add(btnTryItOut,1 , 0);
		pane.add(btnGallery,0 , 1);
		pane.add(btnExit,1 , 1);
		pane.setAlignment(Pos.BOTTOM_CENTER);
		pane.setStyle("-fx-background-color: #EBF7FF");

		GridPane pane1 = new GridPane();
		pane1.setHgap(10);
		pane1.setVgap(10);
		pane1.setPadding(new Insets(10));
		pane1.setAlignment(Pos.TOP_CENTER);
		pane1.add(labelTryYourGeoSkills, 0, 3);
		pane1.getChildren().addAll(new ImageView(world_image));
		pane1.setStyle("-fx-background-color: #EBF7FF");

		BorderPane borderPane = new BorderPane();
		borderPane.setBottom(pane);
		borderPane.setCenter(pane1);

		// Style
		btnAboutQuickQuiz.setPrefWidth(btnSize);
		btnTryItOut.setPrefWidth(btnSize);
		btnGallery.setPrefWidth(btnSize);
		btnExit.setPrefWidth(btnSize);

		labelTryYourGeoSkills.setStyle("-fx-text-fill: grey;-fx-font-size: 2.2em;");
		btnAboutQuickQuiz.setStyle("-fx-background-color: #2A8CCD;-fx-text-fill: White;-fx-font-size: 1.2em;");
		btnTryItOut.setStyle("-fx-text-fill: White;-fx-background-color: #2A8CCD;-fx-font-size: 1.2em; ");
		btnGallery.setStyle("-fx-background-color: #2A8CCD;-fx-text-fill: White;-fx-font-size: 1.2em;");
		btnExit.setStyle("-fx-text-fill: White;-fx-background-color: #2A8CCD;-fx-font-size: 1.2em; ");

		// onAction Stuff
		btnAboutQuickQuiz.setOnAction(e -> {
			try
			{
				Introduction toIntro=new Introduction();toIntro.start(primaryStage); //back to start page
			}
			catch(Exception ex)
			{
				Logger.getLogger(StartUp.class.getName()).log(null);
			}
		});

		btnTryItOut.setOnAction(e ->
		{
			try
			{
				quiz toQuiz = new quiz();
				toQuiz.start(primaryStage);
			}
			catch(Exception ex)
			{
				System.out.println("Something went wrong");
			}
		});

		btnGallery.setOnAction(e -> {
			try
			{
				gallery toGal=new gallery(); toGal.start(primaryStage);
			}
			catch(Exception ex)
			{
				Logger.getLogger(Introduction.class.getName()).log(null);
			}
		});

		btnExit.setOnAction(e ->{
			try
			{
				System.exit(0);
			}
			catch(Exception ex)
			{
				Logger.getLogger(Introduction.class.getName()).log(null);
			}
		});


		Scene scene = new Scene(borderPane,700,650);
		primaryStage.setTitle("WELCOME");
		primaryStage.setScene(scene);
		primaryStage.show();
		primaryStage.setResizable(false);
		primaryStage.getIcons().add(new Image(new File(app_icon).toURI().toString()));

	}

	public static void main(String[] args) {
		launch(args);
	}

}